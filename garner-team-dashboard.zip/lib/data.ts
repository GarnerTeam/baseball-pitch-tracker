import { Phase, Transaction } from '@/types'

export const PHASES: Phase[] = [
  {
    number: 1,
    name: 'Interview to Active',
    shortName: 'Interview',
    description: 'Initial consultation through listing or buyer agreement execution',
  },
  {
    number: 2,
    name: 'Offer / Compromise',
    shortName: 'Offer',
    description: 'Offer preparation, submission, and negotiation',
  },
  {
    number: 3,
    name: 'Acceptance to Contingency Release',
    shortName: 'Contingency',
    description: 'Contract acceptance through all contingency releases',
  },
  {
    number: 4,
    name: 'Settlement',
    shortName: 'Settlement',
    description: 'Final walkthrough through closing day',
  },
  {
    number: 5,
    name: 'Post Closing / Follow Up',
    shortName: 'Post Closing',
    description: 'Post-settlement follow-up and relationship maintenance',
  },
]

export const PHASE_COLORS: Record<number, string> = {
  1: '#418FDE',
  2: '#012169',
  3: '#5C86A0',
  4: '#C9A84C',
  5: '#63666A',
}

export const STATUS_LABELS: Record<string, string> = {
  active: 'Active',
  pending_close: 'Pending Close',
  closed: 'Closed',
  withdrawn: 'Withdrawn',
}

export const ROLE_LABELS: Record<string, string> = {
  buyer: 'Buyer',
  seller: 'Seller',
  coop_agent: 'Coop Agent',
  lender: 'Lender',
  title: 'Title Company',
  tc: 'Transaction Coordinator',
  agent: 'Agent',
}

export const TRANSACTIONS: Transaction[] = [
  {
    id: 'txn-001',
    address: '1234 Maple Drive, Columbia, MD 21044',
    mlsNumber: 'MDHO2045678',
    phase: 3,
    status: 'active',
    type: 'buyer',
    listPrice: 485000,
    salePrice: 492000,
    contractDate: '2026-05-10',
    closingDate: '2026-06-20',
    inspectionDeadline: '2026-05-17',
    financingDeadline: '2026-06-05',
    createdAt: '2026-05-01',
    notes: 'Buyers are relocating from out of state. Flexible on closing date.',
    contacts: [
      { id: 'c1', name: 'John & Mary Smith', email: 'smithfamily@email.com', phone: '410-555-0101', role: 'buyer' },
      { id: 'c2', name: 'Robert Chen', email: 'rchen@cbpremier.com', phone: '410-555-0102', role: 'coop_agent' },
      { id: 'c3', name: 'Amanda Torres', email: 'atorres@firstnational.com', phone: '410-555-0103', role: 'lender' },
      { id: 'c4', name: 'Allied Title Group', email: 'closings@allied.com', phone: '410-555-0104', role: 'title' },
      { id: 'c5', name: 'Sarah Johnson', email: 'sjohnson@garnerteam.com', phone: '410-555-0105', role: 'tc' },
    ],
    tasks: [
      { id: 't1', phase: 1, title: 'Complete buyer consultation', completed: true },
      { id: 't2', phase: 1, title: 'Obtain pre-approval letter', completed: true },
      { id: 't3', phase: 1, title: 'Sign buyer agency agreement', completed: true },
      { id: 't4', phase: 2, title: 'Submit initial offer', completed: true },
      { id: 't5', phase: 2, title: 'Negotiate final terms', completed: true },
      { id: 't6', phase: 2, title: 'Execute sales contract', completed: true },
      { id: 't7', phase: 3, title: 'Schedule home inspection', completed: true },
      { id: 't8', phase: 3, title: 'Review inspection report with buyers', completed: true },
      { id: 't9', phase: 3, title: 'Negotiate inspection repairs / credits', completed: false, dueDate: '2026-05-30', priority: 'high' },
      { id: 't10', phase: 3, title: 'Loan application submitted', completed: true },
      { id: 't11', phase: 3, title: 'Appraisal ordered & completed', completed: false, dueDate: '2026-06-01', priority: 'high' },
      { id: 't12', phase: 3, title: 'Release financing contingency', completed: false, dueDate: '2026-06-05', priority: 'medium' },
      { id: 't13', phase: 4, title: 'Schedule final walkthrough', completed: false, dueDate: '2026-06-18' },
      { id: 't14', phase: 4, title: 'Review HUD-1 / closing disclosure', completed: false, dueDate: '2026-06-18' },
      { id: 't15', phase: 4, title: 'Closing day — Settlement', completed: false, dueDate: '2026-06-20', priority: 'high' },
      { id: 't16', phase: 5, title: 'Send welcome home gift', completed: false },
      { id: 't17', phase: 5, title: 'Request Google / Zillow review', completed: false },
      { id: 't18', phase: 5, title: '30-day check-in call', completed: false },
    ],
  },
  {
    id: 'txn-002',
    address: '567 Oak Lane, Ellicott City, MD 21042',
    mlsNumber: 'MDHO2056789',
    phase: 4,
    status: 'pending_close',
    type: 'seller',
    listPrice: 650000,
    salePrice: 635000,
    contractDate: '2026-04-28',
    closingDate: '2026-06-01',
    inspectionDeadline: '2026-05-10',
    financingDeadline: '2026-05-25',
    createdAt: '2026-04-10',
    contacts: [
      { id: 'c6', name: 'Patricia Williams', email: 'pat.williams@email.com', phone: '410-555-0201', role: 'seller' },
      { id: 'c7', name: 'Michael Davis', email: 'mdavis@remax.com', phone: '410-555-0202', role: 'coop_agent' },
      { id: 'c8', name: 'Capital Mortgage LLC', email: 'loans@capitalmtg.com', phone: '410-555-0203', role: 'lender' },
      { id: 'c9', name: 'Prestige Title', email: 'closing@prestige.com', phone: '410-555-0204', role: 'title' },
      { id: 'c10', name: 'Sarah Johnson', email: 'sjohnson@garnerteam.com', phone: '410-555-0105', role: 'tc' },
    ],
    tasks: [
      { id: 't19', phase: 1, title: 'Listing presentation completed', completed: true },
      { id: 't20', phase: 1, title: 'Execute listing agreement', completed: true },
      { id: 't21', phase: 1, title: 'Professional photography', completed: true },
      { id: 't22', phase: 1, title: 'Go Active on MLS', completed: true },
      { id: 't23', phase: 2, title: 'Review incoming offer', completed: true },
      { id: 't24', phase: 2, title: 'Counteroffer negotiation', completed: true },
      { id: 't25', phase: 2, title: 'Execute sales contract', completed: true },
      { id: 't26', phase: 3, title: 'Buyer inspection completed', completed: true },
      { id: 't27', phase: 3, title: 'Repair credits negotiated', completed: true },
      { id: 't28', phase: 3, title: 'Appraisal completed', completed: true },
      { id: 't29', phase: 3, title: 'All contingencies released', completed: true },
      { id: 't30', phase: 4, title: 'Schedule final walkthrough', completed: true, dueDate: '2026-05-31' },
      { id: 't31', phase: 4, title: 'Review HUD-1 with seller', completed: false, dueDate: '2026-05-30', priority: 'high' },
      { id: 't32', phase: 4, title: 'Closing day — Settlement', completed: false, dueDate: '2026-06-01', priority: 'high' },
      { id: 't33', phase: 5, title: 'Confirm proceeds received', completed: false },
      { id: 't34', phase: 5, title: 'Thank you note & closing gift', completed: false },
      { id: 't35', phase: 5, title: '6-month market update', completed: false },
    ],
  },
  {
    id: 'txn-003',
    address: '890 Birchwood Court, Catonsville, MD 21228',
    mlsNumber: 'MDBC2034567',
    phase: 2,
    status: 'active',
    type: 'buyer',
    listPrice: 375000,
    createdAt: '2026-05-15',
    contacts: [
      { id: 'c11', name: 'David & Lisa Kim', email: 'kim.family@gmail.com', phone: '443-555-0301', role: 'buyer' },
      { id: 'c12', name: 'Jennifer Park', email: 'jpark@kw.com', phone: '443-555-0302', role: 'coop_agent' },
      { id: 'c13', name: 'Prosperity Lending', email: 'info@prosperitylending.com', phone: '443-555-0303', role: 'lender' },
      { id: 'c14', name: 'Sarah Johnson', email: 'sjohnson@garnerteam.com', phone: '410-555-0105', role: 'tc' },
    ],
    tasks: [
      { id: 't36', phase: 1, title: 'Buyer consultation', completed: true },
      { id: 't37', phase: 1, title: 'Pre-approval letter received', completed: true },
      { id: 't38', phase: 1, title: 'Sign buyer agency agreement', completed: true },
      { id: 't39', phase: 2, title: 'Draft initial offer', completed: true },
      { id: 't40', phase: 2, title: 'Submit offer to listing agent', completed: false, dueDate: '2026-05-29', priority: 'high' },
      { id: 't41', phase: 2, title: 'Negotiate terms', completed: false },
      { id: 't42', phase: 2, title: 'Execute contract', completed: false },
    ],
  },
  {
    id: 'txn-004',
    address: '321 Pine Street, Towson, MD 21204',
    mlsNumber: 'MDBC2045123',
    phase: 1,
    status: 'active',
    type: 'seller',
    listPrice: 520000,
    createdAt: '2026-05-20',
    contacts: [
      { id: 'c15', name: 'Thomas Anderson', email: 't.anderson@work.com', phone: '410-555-0401', role: 'seller' },
      { id: 'c16', name: 'Sarah Johnson', email: 'sjohnson@garnerteam.com', phone: '410-555-0105', role: 'tc' },
    ],
    tasks: [
      { id: 't43', phase: 1, title: 'Initial seller consultation', completed: true },
      { id: 't44', phase: 1, title: 'CMA / pricing analysis', completed: true },
      { id: 't45', phase: 1, title: 'Execute listing agreement', completed: false, dueDate: '2026-05-29', priority: 'high' },
      { id: 't46', phase: 1, title: 'Home prep / staging consultation', completed: false, dueDate: '2026-05-30', priority: 'medium' },
      { id: 't47', phase: 1, title: 'Order professional photography', completed: false, dueDate: '2026-06-02', priority: 'medium' },
      { id: 't48', phase: 1, title: 'Go Active on MLS', completed: false, dueDate: '2026-06-06', priority: 'medium' },
    ],
  },
  {
    id: 'txn-005',
    address: '755 Willow Way, Pikesville, MD 21208',
    mlsNumber: 'MDBC2038901',
    phase: 5,
    status: 'closed',
    type: 'buyer',
    listPrice: 410000,
    salePrice: 410000,
    contractDate: '2026-04-01',
    closingDate: '2026-05-15',
    createdAt: '2026-03-15',
    contacts: [
      { id: 'c17', name: 'Marcus & Diana Johnson', email: 'marcusdiana@email.com', phone: '410-555-0501', role: 'buyer' },
      { id: 'c18', name: 'Kevin Wright', email: 'kwright@longfoster.com', phone: '410-555-0502', role: 'coop_agent' },
      { id: 'c19', name: 'Harbor Mortgage', email: 'loans@harbormtg.com', phone: '410-555-0503', role: 'lender' },
      { id: 'c20', name: 'Bay Title', email: 'closings@baytitle.com', phone: '410-555-0504', role: 'title' },
      { id: 'c21', name: 'Sarah Johnson', email: 'sjohnson@garnerteam.com', phone: '410-555-0105', role: 'tc' },
    ],
    tasks: [
      { id: 't49', phase: 1, title: 'Buyer consultation', completed: true },
      { id: 't50', phase: 1, title: 'Pre-approval letter received', completed: true },
      { id: 't51', phase: 2, title: 'Offer negotiated & executed', completed: true },
      { id: 't52', phase: 3, title: 'All contingencies cleared', completed: true },
      { id: 't53', phase: 4, title: 'Settlement completed', completed: true },
      { id: 't54', phase: 5, title: 'Send welcome home gift', completed: true },
      { id: 't55', phase: 5, title: 'Request Google / Zillow review', completed: false, priority: 'medium' },
      { id: 't56', phase: 5, title: '30-day check-in call', completed: false, dueDate: '2026-06-14', priority: 'low' },
      { id: 't57', phase: 5, title: '6-month market update', completed: false, dueDate: '2026-11-15', priority: 'low' },
      { id: 't58', phase: 5, title: '1-year anniversary outreach', completed: false },
    ],
  },
  {
    id: 'txn-006',
    address: '44 Cedar Ridge Rd, Owings Mills, MD 21117',
    mlsNumber: 'MDBC2051290',
    phase: 1,
    status: 'active',
    type: 'buyer',
    listPrice: 440000,
    createdAt: '2026-05-24',
    contacts: [
      { id: 'c22', name: 'Samantha & Greg Torres', email: 'storres@outlook.com', phone: '443-555-0601', role: 'buyer' },
      { id: 'c23', name: 'Sarah Johnson', email: 'sjohnson@garnerteam.com', phone: '410-555-0105', role: 'tc' },
    ],
    tasks: [
      { id: 't59', phase: 1, title: 'Buyer consultation', completed: true },
      { id: 't60', phase: 1, title: 'Pre-approval letter', completed: false, dueDate: '2026-05-31', priority: 'high' },
      { id: 't61', phase: 1, title: 'Sign buyer agency agreement', completed: false, dueDate: '2026-05-31', priority: 'high' },
    ],
  },
]

// ─── Helpers ──────────────────────────────────────────────────────────────────

export function formatCurrency(amount: number): string {
  if (amount >= 1000000) {
    return '$' + (amount / 1000000).toFixed(2).replace(/\.?0+$/, '') + 'M'
  }
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

export function formatDate(dateString: string): string {
  return new Date(dateString + 'T12:00:00').toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })
}

export function getDaysUntil(dateString: string): number {
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const target = new Date(dateString + 'T12:00:00')
  target.setHours(0, 0, 0, 0)
  return Math.round((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
}

export function getPhaseColor(phase: number): string {
  return PHASE_COLORS[phase] ?? '#012169'
}
