"use client"

import { createContext, useContext, useState, ReactNode } from "react"
import { Transaction } from "@/types"
import { TRANSACTIONS as SEED } from "@/lib/data"

interface Store {
  transactions: Transaction[]
  addTransaction: (txn: Transaction) => void
  updateTransaction: (id: string, updates: Partial<Transaction>) => void
}

const Ctx = createContext<Store | null>(null)

export function TransactionProvider({ children }: { children: ReactNode }) {
  const [transactions, setTransactions] = useState<Transaction[]>([...SEED])

  const addTransaction = (txn: Transaction) =>
    setTransactions((p) => [txn, ...p])

  const updateTransaction = (id: string, updates: Partial<Transaction>) =>
    setTransactions((p) => p.map((t) => (t.id === id ? { ...t, ...updates } : t)))

  return (
    <Ctx.Provider value={{ transactions, addTransaction, updateTransaction }}>
      {children}
    </Ctx.Provider>
  )
}

export function useTransactions() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error("useTransactions must be used inside TransactionProvider")
  return ctx
}
