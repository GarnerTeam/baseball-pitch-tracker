"use client"

import { useState, useMemo } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import {
  TRANSACTIONS, PHASES, ROLE_LABELS, STATUS_LABELS,
  formatCurrency, formatDate, getDaysUntil, getPhaseColor,
} from "@/lib/data"
import { Transaction, UserRole, Task, PhaseNumber } from "@/types"
import { PhaseStepper } from "@/components/phase-stepper"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowLeft, Calendar, CheckCircle, Users, Clock,
  Phone, Mail, Hash, MapPin, AlertCircle, FileText,
} from "lucide-react"
import { cn } from "@/lib/utils"

const ROLE_COLORS: Record<string, string> = {
  buyer: "bg-blue-100 text-blue-800",
  seller: "bg-purple-100 text-purple-800",
  coop_agent: "bg-orange-100 text-orange-800",
  lender: "bg-green-100 text-green-800",
  title: "bg-teal-100 text-teal-800",
  tc: "bg-[#012169]/10 text-[#012169]",
  agent: "bg-[#012169]/10 text-[#012169]",
}

const STATUS_STYLES: Record<string, string> = {
  active: "bg-emerald-100 text-emerald-800",
  pending_close: "bg-amber-100 text-amber-800",
  closed: "bg-gray-100 text-gray-600",
  withdrawn: "bg-red-100 text-red-800",
}

// ─── Role-specific task filter ────────────────────────────────────────────────
function getVisibleTasks(tasks: Task[], role: UserRole, currentPhase: PhaseNumber) {
  if (role === "tc") return tasks
  if (role === "client") {
    return tasks.filter(
      (t) => t.phase === currentPhase || (t.phase === currentPhase + 1 && !t.completed)
    )
  }
  // coop_agent: show current phase + high-priority tasks
  return tasks.filter(
    (t) => t.phase === currentPhase || t.priority === "high"
  )
}

// ─── Phase summary messages ──────────────────────────────────────────────────
const PHASE_CLIENT_MSG: Record<number, { heading: string; body: string }> = {
  1: {
    heading: "We're getting started!",
    body: "We're preparing your listing or buyer consultation. Our team is setting everything up to get you to market quickly.",
  },
  2: {
    heading: "Offer stage — let's negotiate!",
    body: "We're working on your offer. Our job is to get you the best terms possible. We'll keep you posted on every response.",
  },
  3: {
    heading: "Under contract — working through contingencies",
    body: "Great news — you have an accepted contract! Now we're navigating inspections, appraisal, and financing. Stay close, we may need a few things from you.",
  },
  4: {
    heading: "Almost there — settlement is near!",
    body: "All contingencies are cleared. We're heading to the closing table! Keep an eye on your email for the closing disclosure and final numbers.",
  },
  5: {
    heading: "Congratulations — you did it!",
    body: "Settlement is complete. Thank you for trusting the Garner Team. We'll check in soon — and we'd love a review if you have a moment!",
  },
}

// ─── Component ───────────────────────────────────────────────────────────────
export default function TransactionDetailPage() {
  const params = useParams()
  const id = params.id as string

  const [transaction, setTransaction] = useState<Transaction | null>(
    () => TRANSACTIONS.find((t) => t.id === id) ?? null
  )
  const [role, setRole] = useState<UserRole>("tc")

  if (!transaction) {
    return (
      <div className="p-8 text-center">
        <p className="text-gray-500">Transaction not found.</p>
        <Link href="/" className="text-[#012169] hover:underline text-sm mt-2 inline-block">← Back to Dashboard</Link>
      </div>
    )
  }

  const phaseColor = getPhaseColor(transaction.phase)
  const daysToClose = transaction.closingDate ? getDaysUntil(transaction.closingDate) : null
  const visibleTasks = getVisibleTasks(transaction.tasks, role, transaction.phase)

  const tasksByPhase = useMemo(() => {
    const map: Partial<Record<PhaseNumber, Task[]>> = {}
    for (const task of visibleTasks) {
      if (!map[task.phase]) map[task.phase] = []
      map[task.phase]!.push(task)
    }
    return map
  }, [visibleTasks])

  const completedAll = transaction.tasks.filter((t) => t.completed).length
  const totalAll = transaction.tasks.length
  const overallProgress = totalAll > 0 ? Math.round((completedAll / totalAll) * 100) : 0

  const toggleTask = (taskId: string) => {
    setTransaction((prev) => {
      if (!prev) return null
      return {
        ...prev,
        tasks: prev.tasks.map((t) => (t.id === taskId ? { ...t, completed: !t.completed } : t)),
      }
    })
  }

  // Contacts to show per role
  const visibleContacts = transaction.contacts.filter((c) => {
    if (role === "tc") return true
    if (role === "client") return ["agent", "tc", "lender", "title"].includes(c.role)
    if (role === "coop_agent") return ["agent", "tc"].includes(c.role)
    return true
  })

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Back */}
      <Link
        href="/"
        className="inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-[#012169] mb-4 transition-colors"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        Back to Dashboard
      </Link>

      {/* Header card */}
      <Card className="border-0 shadow-sm mb-4 overflow-hidden">
        <div className="h-1.5 w-full" style={{ backgroundColor: phaseColor }} />
        <CardContent className="p-5">
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-2">
                <span className={cn("text-xs font-semibold px-2.5 py-1 rounded-full", STATUS_STYLES[transaction.status])}>
                  {STATUS_LABELS[transaction.status]}
                </span>
                <span className={cn(
                  "text-xs font-semibold px-2.5 py-1 rounded-full",
                  transaction.type === "buyer" ? "bg-blue-50 text-blue-700" : "bg-purple-50 text-purple-700"
                )}>
                  {transaction.type === "buyer" ? "Buyer Side" : "Seller Side"}
                </span>
              </div>
              <div className="flex items-start gap-2 mb-1">
                <MapPin className="h-4 w-4 text-gray-400 mt-0.5 flex-shrink-0" />
                <h1 className="text-xl font-bold text-[#2D2926] leading-snug">{transaction.address}</h1>
              </div>
              <div className="flex items-center gap-4 text-sm text-gray-500 ml-6">
                <span className="flex items-center gap-1">
                  <Hash className="h-3 w-3" />
                  {transaction.mlsNumber}
                </span>
                <span className="font-bold text-[#2D2926] text-base">
                  {transaction.salePrice
                    ? formatCurrency(transaction.salePrice)
                    : formatCurrency(transaction.listPrice)}
                </span>
                {transaction.salePrice && transaction.salePrice !== transaction.listPrice && (
                  <span className="line-through text-gray-400 text-sm">{formatCurrency(transaction.listPrice)}</span>
                )}
              </div>
            </div>

            {/* Key date callout */}
            {transaction.closingDate && daysToClose !== null && (
              <div
                className={cn(
                  "text-center px-5 py-3 rounded-xl border-2",
                  daysToClose <= 7 ? "border-red-200 bg-red-50" :
                  daysToClose <= 14 ? "border-amber-200 bg-amber-50" :
                  "border-gray-100 bg-gray-50"
                )}
              >
                <p className={cn("text-2xl font-bold", daysToClose <= 7 ? "text-red-600" : daysToClose <= 14 ? "text-amber-600" : "text-[#012169]")}>
                  {daysToClose < 0 ? "Past" : daysToClose === 0 ? "Today" : daysToClose}
                </p>
                <p className="text-xs text-gray-500 font-medium">
                  {daysToClose > 0 ? "days to closing" : "Closing date"}
                </p>
                <p className="text-xs text-gray-400 mt-0.5">{formatDate(transaction.closingDate)}</p>
              </div>
            )}
          </div>

          {/* Overall progress */}
          <div className="mt-4">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="text-gray-500">Overall Progress</span>
              <span className="font-semibold text-gray-700">{completedAll}/{totalAll} tasks · {overallProgress}%</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all"
                style={{ width: `${overallProgress}%`, backgroundColor: phaseColor }}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Phase Stepper */}
      <Card className="border-0 shadow-sm mb-4">
        <CardContent className="py-5 px-6">
          <PhaseStepper currentPhase={transaction.phase} />
        </CardContent>
      </Card>

      {/* Role toggle */}
      <div className="flex items-center gap-2 mb-4">
        <span className="text-xs text-gray-500 font-medium">Viewing as:</span>
        {(["tc", "client", "coop_agent"] as UserRole[]).map((r) => {
          const labels: Record<UserRole, string> = {
            tc: "TC / Staff",
            client: "Client",
            coop_agent: "Coop Agent",
          }
          return (
            <button
              key={r}
              onClick={() => setRole(r)}
              className={cn(
                "px-3 py-1.5 rounded-full text-xs font-medium transition-all",
                role === r
                  ? "bg-[#012169] text-white shadow-sm"
                  : "bg-white text-gray-600 border border-gray-200 hover:border-[#012169]/40"
              )}
            >
              {labels[r]}
            </button>
          )
        })}
      </div>

      {/* Tabs */}
      <Tabs defaultValue="overview">
        <TabsList className="bg-white border border-gray-100 shadow-sm mb-4 p-1">
          <TabsTrigger value="overview" className="text-xs data-[state=active]:bg-[#012169] data-[state=active]:text-white">Overview</TabsTrigger>
          <TabsTrigger value="tasks" className="text-xs data-[state=active]:bg-[#012169] data-[state=active]:text-white">
            Tasks ({visibleTasks.filter((t) => !t.completed).length} open)
          </TabsTrigger>
          <TabsTrigger value="contacts" className="text-xs data-[state=active]:bg-[#012169] data-[state=active]:text-white">Contacts</TabsTrigger>
          <TabsTrigger value="dates" className="text-xs data-[state=active]:bg-[#012169] data-[state=active]:text-white">Key Dates</TabsTrigger>
        </TabsList>

        {/* ─── OVERVIEW ─── */}
        <TabsContent value="overview">
          <div className="space-y-4">
            {role === "client" && (
              <Card className="border-0 shadow-sm" style={{ borderLeft: `4px solid ${phaseColor}` }}>
                <CardContent className="p-5">
                  <p className="font-bold text-[#2D2926] mb-1">{PHASE_CLIENT_MSG[transaction.phase].heading}</p>
                  <p className="text-sm text-gray-600 leading-relaxed">{PHASE_CLIENT_MSG[transaction.phase].body}</p>
                </CardContent>
              </Card>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Current Phase */}
              <Card className="border-0 shadow-sm">
                <CardHeader className="pb-2 pt-4 px-5">
                  <CardTitle className="text-sm font-semibold text-gray-600">Current Phase</CardTitle>
                </CardHeader>
                <CardContent className="px-5 pb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold text-sm" style={{ backgroundColor: phaseColor }}>
                      {["I", "II", "III", "IV", "V"][transaction.phase - 1]}
                    </div>
                    <div>
                      <p className="font-semibold text-[#2D2926] text-sm">{PHASES[transaction.phase - 1].name}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{PHASES[transaction.phase - 1].description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Upcoming tasks */}
              <Card className="border-0 shadow-sm">
                <CardHeader className="pb-2 pt-4 px-5">
                  <CardTitle className="text-sm font-semibold text-gray-600">
                    {role === "client" ? "Your Next Steps" : "Upcoming Tasks"}
                  </CardTitle>
                </CardHeader>
                <CardContent className="px-5 pb-4 space-y-2">
                  {visibleTasks
                    .filter((t) => !t.completed)
                    .slice(0, 4)
                    .map((task) => (
                      <div key={task.id} className="flex items-start gap-2 text-xs">
                        <div className="w-1.5 h-1.5 rounded-full bg-[#012169] mt-1.5 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <span className="text-gray-700">{task.title}</span>
                          {task.dueDate && (
                            <span className={cn(
                              "ml-2 font-medium",
                              getDaysUntil(task.dueDate) <= 3 ? "text-red-500" : "text-gray-400"
                            )}>
                              Due {formatDate(task.dueDate)}
                            </span>
                          )}
                        </div>
                        {task.priority === "high" && (
                          <AlertCircle className="h-3 w-3 text-red-400 flex-shrink-0" />
                        )}
                      </div>
                    ))}
                  {visibleTasks.filter((t) => !t.completed).length === 0 && (
                    <p className="text-xs text-gray-400">All tasks complete! 🎉</p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Transaction notes (TC only) */}
            {role === "tc" && transaction.notes && (
              <Card className="border-0 shadow-sm">
                <CardHeader className="pb-2 pt-4 px-5">
                  <CardTitle className="text-sm font-semibold text-gray-600 flex items-center gap-2">
                    <FileText className="h-4 w-4" /> Internal Notes
                  </CardTitle>
                </CardHeader>
                <CardContent className="px-5 pb-4">
                  <p className="text-sm text-gray-600 leading-relaxed">{transaction.notes}</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* ─── TASKS ─── */}
        <TabsContent value="tasks">
          <div className="space-y-4">
            {role === "client" && (
              <p className="text-xs text-gray-500 bg-blue-50 border border-blue-100 rounded-lg px-4 py-2.5">
                Showing tasks for your current phase and next steps. Your TC manages the full checklist behind the scenes.
              </p>
            )}
            {(Object.keys(tasksByPhase) as unknown as PhaseNumber[])
              .map(Number)
              .sort((a, b) => a - b)
              .map((phaseNum) => {
                const phaseTasks = tasksByPhase[phaseNum as PhaseNumber] ?? []
                const completed = phaseTasks.filter((t) => t.completed).length
                const pc = getPhaseColor(phaseNum)
                return (
                  <Card key={phaseNum} className="border-0 shadow-sm overflow-hidden">
                    <div className="h-0.5 w-full" style={{ backgroundColor: pc }} />
                    <CardHeader className="py-3 px-5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded text-white text-[10px] font-bold flex items-center justify-center" style={{ backgroundColor: pc }}>
                            {["I", "II", "III", "IV", "V"][phaseNum - 1]}
                          </span>
                          <span className="text-sm font-semibold text-[#2D2926]">{PHASES[phaseNum - 1].name}</span>
                        </div>
                        <span className="text-xs text-gray-400">{completed}/{phaseTasks.length} done</span>
                      </div>
                    </CardHeader>
                    <CardContent className="px-5 pb-4 space-y-2">
                      {phaseTasks.map((task) => (
                        <div
                          key={task.id}
                          className={cn(
                            "flex items-start gap-3 p-2.5 rounded-lg transition-colors",
                            task.completed ? "bg-gray-50" : "bg-white hover:bg-gray-50",
                            role !== "tc" && "cursor-default"
                          )}
                        >
                          <button
                            onClick={() => role === "tc" && toggleTask(task.id)}
                            className={cn(
                              "w-4 h-4 rounded border-2 flex items-center justify-center flex-shrink-0 mt-0.5 transition-all",
                              task.completed
                                ? "border-transparent"
                                : "border-gray-300",
                              role === "tc" && !task.completed && "hover:border-[#012169] cursor-pointer",
                              role !== "tc" && "cursor-default"
                            )}
                            style={task.completed ? { backgroundColor: pc, borderColor: pc } : {}}
                          >
                            {task.completed && (
                              <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                              </svg>
                            )}
                          </button>
                          <div className="flex-1 min-w-0">
                            <p className={cn("text-sm leading-snug", task.completed ? "line-through text-gray-400" : "text-gray-700")}>
                              {task.title}
                            </p>
                            {task.dueDate && !task.completed && (
                              <p className={cn(
                                "text-xs mt-0.5 flex items-center gap-1",
                                getDaysUntil(task.dueDate) <= 0 ? "text-red-500 font-medium" :
                                getDaysUntil(task.dueDate) <= 3 ? "text-amber-500" : "text-gray-400"
                              )}>
                                <Clock className="h-3 w-3" />
                                Due {formatDate(task.dueDate)}
                                {getDaysUntil(task.dueDate) <= 0 && " — OVERDUE"}
                              </p>
                            )}
                          </div>
                          {task.priority === "high" && !task.completed && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-red-100 text-red-600 uppercase tracking-wide flex-shrink-0">
                              High
                            </span>
                          )}
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )
              })}
          </div>
        </TabsContent>

        {/* ─── CONTACTS ─── */}
        <TabsContent value="contacts">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {visibleContacts.map((contact) => (
              <Card key={contact.id} className="border-0 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0 text-sm font-bold text-gray-500">
                      {contact.name.split(" ").map((n) => n[0]).slice(0, 2).join("")}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <p className="font-semibold text-[#2D2926] text-sm leading-snug">{contact.name}</p>
                        <span className={cn("text-[10px] font-semibold px-2 py-0.5 rounded-full flex-shrink-0", ROLE_COLORS[contact.role] ?? "bg-gray-100 text-gray-600")}>
                          {ROLE_LABELS[contact.role]}
                        </span>
                      </div>
                      <div className="mt-2 space-y-1">
                        <a href={`mailto:${contact.email}`} className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-[#012169] transition-colors">
                          <Mail className="h-3 w-3" />
                          {contact.email}
                        </a>
                        <a href={`tel:${contact.phone}`} className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-[#012169] transition-colors">
                          <Phone className="h-3 w-3" />
                          {contact.phone}
                        </a>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            {visibleContacts.length === 0 && (
              <p className="text-sm text-gray-400 col-span-2 py-8 text-center">No contacts to display for this view.</p>
            )}
          </div>
        </TabsContent>

        {/* ─── KEY DATES ─── */}
        <TabsContent value="dates">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-5">
              <div className="space-y-0">
                {[
                  { label: "Contract Date", value: transaction.contractDate, icon: FileText },
                  { label: "Inspection Deadline", value: transaction.inspectionDeadline, icon: AlertCircle },
                  { label: "Financing Deadline", value: transaction.financingDeadline, icon: CheckCircle },
                  { label: "Closing / Settlement", value: transaction.closingDate, icon: Calendar },
                ].map((item, idx) => {
                  if (!item.value) return null
                  const days = getDaysUntil(item.value)
                  const isPast = days < 0
                  const isUrgent = days >= 0 && days <= 7
                  const Icon = item.icon
                  return (
                    <div key={idx} className={cn("flex items-center gap-4 py-4", idx > 0 && "border-t border-gray-50")}>
                      <div className={cn(
                        "w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0",
                        isPast ? "bg-gray-100" : isUrgent ? "bg-red-50" : "bg-[#012169]/8"
                      )}>
                        <Icon className={cn("h-4 w-4", isPast ? "text-gray-400" : isUrgent ? "text-red-500" : "text-[#012169]")} />
                      </div>
                      <div className="flex-1">
                        <p className="text-xs text-gray-500 font-medium">{item.label}</p>
                        <p className="text-sm font-semibold text-[#2D2926]">{formatDate(item.value)}</p>
                      </div>
                      <div className="text-right">
                        {isPast ? (
                          <span className="text-xs text-gray-400 bg-gray-100 px-2 py-1 rounded-full">Passed</span>
                        ) : days === 0 ? (
                          <span className="text-xs font-bold text-red-600 bg-red-50 px-2 py-1 rounded-full">TODAY</span>
                        ) : (
                          <span className={cn(
                            "text-xs font-semibold px-2 py-1 rounded-full",
                            isUrgent ? "bg-red-50 text-red-600" : days <= 14 ? "bg-amber-50 text-amber-600" : "bg-[#012169]/8 text-[#012169]"
                          )}>
                            {days}d away
                          </span>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
