"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { useTransactions } from "@/lib/transaction-store"
import { NewTransactionDialog } from "@/components/new-transaction-dialog"
import { formatCurrency, formatDate, getDaysUntil, getPhaseColor, PHASES, STATUS_LABELS } from "@/lib/data"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, ExternalLink, ChevronUp, ChevronDown } from "lucide-react"
import { cn } from "@/lib/utils"

const STATUS_STYLES: Record<string, string> = {
  active: "bg-emerald-100 text-emerald-800",
  pending_close: "bg-amber-100 text-amber-800",
  closed: "bg-gray-100 text-gray-600",
  withdrawn: "bg-red-100 text-red-800",
}

type SortKey = "address" | "phase" | "listPrice" | "closingDate" | "status"

export default function TransactionsPage() {
  const { transactions } = useTransactions()
  const [search, setSearch] = useState("")
  const [sortKey, setSortKey] = useState<SortKey>("phase")
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc")

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"))
    else { setSortKey(key); setSortDir("asc") }
  }

  const filtered = useMemo(() => {
    const q = search.toLowerCase()
    const list = transactions.filter(
      (t) =>
        t.address.toLowerCase().includes(q) ||
        t.mlsNumber.toLowerCase().includes(q) ||
        t.contacts.some((c) => c.name.toLowerCase().includes(q))
    )
    return [...list].sort((a, b) => {
      let av: string | number = ""
      let bv: string | number = ""
      if (sortKey === "address") { av = a.address; bv = b.address }
      if (sortKey === "phase") { av = a.phase; bv = b.phase }
      if (sortKey === "listPrice") { av = a.salePrice ?? a.listPrice; bv = b.salePrice ?? b.listPrice }
      if (sortKey === "closingDate") { av = a.closingDate ?? ""; bv = b.closingDate ?? "" }
      if (sortKey === "status") { av = a.status; bv = b.status }
      if (av < bv) return sortDir === "asc" ? -1 : 1
      if (av > bv) return sortDir === "asc" ? 1 : -1
      return 0
    })
  }, [transactions, search, sortKey, sortDir])

  const SortIcon = ({ col }: { col: SortKey }) =>
    sortKey === col ? (
      sortDir === "asc" ? <ChevronUp className="h-3 w-3 inline ml-1" /> : <ChevronDown className="h-3 w-3 inline ml-1" />
    ) : null

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-[#2D2926]">All Transactions</h1>
          <p className="text-gray-500 text-sm mt-0.5">{transactions.length} total · {transactions.filter(t => t.status === "active" || t.status === "pending_close").length} active</p>
        </div>
        <NewTransactionDialog />
      </div>

      {/* Search */}
      <Card className="border-0 shadow-sm mb-4">
        <CardContent className="p-3">
          <div className="relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search by address, MLS number, or client name…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 border-0 bg-transparent focus-visible:ring-0 text-sm"
            />
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="border-0 shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-50 hover:bg-gray-50">
              <TableHead
                className="text-xs font-semibold text-gray-500 cursor-pointer select-none"
                onClick={() => toggleSort("address")}
              >
                Property <SortIcon col="address" />
              </TableHead>
              <TableHead className="text-xs font-semibold text-gray-500">Type</TableHead>
              <TableHead
                className="text-xs font-semibold text-gray-500 cursor-pointer select-none"
                onClick={() => toggleSort("phase")}
              >
                Phase <SortIcon col="phase" />
              </TableHead>
              <TableHead
                className="text-xs font-semibold text-gray-500 cursor-pointer select-none"
                onClick={() => toggleSort("status")}
              >
                Status <SortIcon col="status" />
              </TableHead>
              <TableHead
                className="text-xs font-semibold text-gray-500 cursor-pointer select-none text-right"
                onClick={() => toggleSort("listPrice")}
              >
                Price <SortIcon col="listPrice" />
              </TableHead>
              <TableHead
                className="text-xs font-semibold text-gray-500 cursor-pointer select-none"
                onClick={() => toggleSort("closingDate")}
              >
                Closing <SortIcon col="closingDate" />
              </TableHead>
              <TableHead className="text-xs font-semibold text-gray-500">Tasks</TableHead>
              <TableHead className="w-10" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((txn) => {
              const phaseColor = getPhaseColor(txn.phase)
              const done = txn.tasks.filter((t) => t.completed).length
              const total = txn.tasks.length
              const pct = total > 0 ? Math.round((done / total) * 100) : 0
              const daysToClose = txn.closingDate ? getDaysUntil(txn.closingDate) : null
              const client = txn.contacts.find(
                (c) => c.role === "buyer" || c.role === "seller"
              )

              return (
                <TableRow key={txn.id} className="hover:bg-blue-50/30 transition-colors">
                  <TableCell>
                    <div>
                      <p className="font-medium text-[#2D2926] text-sm leading-snug">{txn.address}</p>
                      <p className="text-xs text-gray-400 mt-0.5">
                        #{txn.mlsNumber}
                        {client && <span className="ml-2 text-gray-500">{client.name}</span>}
                      </p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className={cn(
                      "text-[10px] font-semibold px-2 py-0.5 rounded-full",
                      txn.type === "buyer" ? "bg-blue-50 text-blue-700" : "bg-purple-50 text-purple-700"
                    )}>
                      {txn.type === "buyer" ? "Buyer" : "Seller"}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span
                        className="w-5 h-5 rounded text-white text-[9px] font-bold flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: phaseColor }}
                      >
                        {["I", "II", "III", "IV", "V"][txn.phase - 1]}
                      </span>
                      <span className="text-xs text-gray-600 hidden lg:block">
                        {PHASES[txn.phase - 1].shortName}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className={cn("text-[10px] font-semibold px-2 py-0.5 rounded-full", STATUS_STYLES[txn.status])}>
                      {STATUS_LABELS[txn.status]}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <p className="font-semibold text-sm text-[#2D2926]">
                      {formatCurrency(txn.salePrice ?? txn.listPrice)}
                    </p>
                    {txn.salePrice && txn.salePrice !== txn.listPrice && (
                      <p className="text-xs text-gray-400 line-through">{formatCurrency(txn.listPrice)}</p>
                    )}
                  </TableCell>
                  <TableCell>
                    {txn.closingDate && daysToClose !== null ? (
                      <div>
                        <p className="text-xs text-gray-600">{formatDate(txn.closingDate)}</p>
                        <p className={cn(
                          "text-[10px] font-medium",
                          daysToClose < 0 ? "text-gray-400" :
                          daysToClose <= 7 ? "text-red-500" :
                          daysToClose <= 14 ? "text-amber-500" : "text-gray-400"
                        )}>
                          {daysToClose < 0 ? "Passed" : daysToClose === 0 ? "TODAY" : `${daysToClose}d away`}
                        </p>
                      </div>
                    ) : (
                      <span className="text-xs text-gray-300">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${pct}%`, backgroundColor: phaseColor }} />
                      </div>
                      <span className="text-[10px] text-gray-400">{pct}%</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Link
                      href={`/transactions/${txn.id}`}
                      className="text-gray-400 hover:text-[#012169] transition-colors"
                    >
                      <ExternalLink className="h-4 w-4" />
                    </Link>
                  </TableCell>
                </TableRow>
              )
            })}
            {filtered.length === 0 && (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-12 text-gray-400 text-sm">
                  No transactions match your search.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  )
}
