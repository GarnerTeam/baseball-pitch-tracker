"use client"

import { useState, useMemo } from "react"
import { useTransactions } from "@/lib/transaction-store"
import { PHASES, formatCurrency } from "@/lib/data"
import { TransactionCard } from "@/components/transaction-card"
import { NewTransactionDialog } from "@/components/new-transaction-dialog"
import { Card, CardContent } from "@/components/ui/card"
import { FileText, TrendingUp, Calendar, CheckCircle, SlidersHorizontal } from "lucide-react"
import { cn } from "@/lib/utils"

type Filter = "all" | "active" | `phase-${1 | 2 | 3 | 4 | 5}` | "closed"

const FILTER_BUTTONS: { key: Filter; label: string }[] = [
  { key: "all", label: "All" },
  { key: "active", label: "Active" },
  { key: "phase-1", label: "Phase I" },
  { key: "phase-2", label: "Phase II" },
  { key: "phase-3", label: "Phase III" },
  { key: "phase-4", label: "Phase IV" },
  { key: "phase-5", label: "Phase V" },
  { key: "closed", label: "Closed" },
]

export default function DashboardPage() {
  const { transactions } = useTransactions()
  const [filter, setFilter] = useState<Filter>("all")

  const stats = useMemo(() => {
    const active = transactions.filter((t) => t.status === "active" || t.status === "pending_close")
    const closingThisMonth = transactions.filter((t) => {
      if (!t.closingDate) return false
      const d = new Date(t.closingDate + "T12:00:00")
      const now = new Date()
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear()
    })
    const totalVolume = active.reduce((s, t) => s + (t.salePrice ?? t.listPrice), 0)
    const pendingTasks = transactions.flatMap((t) => t.tasks).filter((t) => !t.completed).length
    return { active: active.length, closingThisMonth: closingThisMonth.length, totalVolume, pendingTasks }
  }, [transactions])

  const filtered = useMemo(() => {
    if (filter === "all") return transactions
    if (filter === "active") return transactions.filter((t) => t.status === "active" || t.status === "pending_close")
    if (filter === "closed") return transactions.filter((t) => t.status === "closed")
    const phase = parseInt(filter.split("-")[1])
    return transactions.filter((t) => t.phase === phase)
  }, [filter, transactions])

  const phaseCount = (phase: number) => transactions.filter((t) => t.phase === phase).length

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-[#2D2926]">Transaction Dashboard</h1>
          <p className="text-gray-500 text-sm mt-0.5">Garner Team · Coldwell Banker Realty</p>
        </div>
        <NewTransactionDialog />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card className="border-0 shadow-sm overflow-hidden">
          <div className="h-1 bg-[#012169]" />
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 font-medium uppercase tracking-wide mb-1">Active</p>
                <p className="text-3xl font-bold text-[#2D2926]">{stats.active}</p>
                <p className="text-xs text-gray-400 mt-0.5">transactions</p>
              </div>
              <div className="w-11 h-11 rounded-xl bg-[#012169]/8 flex items-center justify-center">
                <FileText className="h-5 w-5 text-[#012169]" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm overflow-hidden">
          <div className="h-1 bg-[#C9A84C]" />
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 font-medium uppercase tracking-wide mb-1">Closing</p>
                <p className="text-3xl font-bold text-[#2D2926]">{stats.closingThisMonth}</p>
                <p className="text-xs text-gray-400 mt-0.5">this month</p>
              </div>
              <div className="w-11 h-11 rounded-xl bg-[#C9A84C]/10 flex items-center justify-center">
                <Calendar className="h-5 w-5 text-[#C9A84C]" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm overflow-hidden">
          <div className="h-1 bg-[#418FDE]" />
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 font-medium uppercase tracking-wide mb-1">Pipeline</p>
                <p className="text-3xl font-bold text-[#2D2926]">{formatCurrency(stats.totalVolume)}</p>
                <p className="text-xs text-gray-400 mt-0.5">active volume</p>
              </div>
              <div className="w-11 h-11 rounded-xl bg-[#418FDE]/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-[#418FDE]" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm overflow-hidden">
          <div className="h-1 bg-[#5C86A0]" />
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 font-medium uppercase tracking-wide mb-1">Pending</p>
                <p className="text-3xl font-bold text-[#2D2926]">{stats.pendingTasks}</p>
                <p className="text-xs text-gray-400 mt-0.5">open tasks</p>
              </div>
              <div className="w-11 h-11 rounded-xl bg-[#5C86A0]/10 flex items-center justify-center">
                <CheckCircle className="h-5 w-5 text-[#5C86A0]" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Phase breakdown */}
      <Card className="border-0 shadow-sm mb-6">
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">By Phase</p>
            <div className="flex-1 flex gap-2 flex-wrap">
              {PHASES.map((phase, i) => {
                const count = phaseCount(phase.number)
                const colors = ["#418FDE", "#012169", "#5C86A0", "#C9A84C", "#63666A"]
                const isActive = filter === `phase-${phase.number}`
                return (
                  <button
                    key={phase.number}
                    onClick={() => setFilter(`phase-${phase.number}` as Filter)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all hover:shadow-sm"
                    style={{
                      borderColor: isActive ? colors[i] : "transparent",
                      backgroundColor: isActive ? `${colors[i]}15` : "#F8F9FA",
                      color: isActive ? colors[i] : "#63666A",
                    }}
                  >
                    <span
                      className="w-4 h-4 rounded text-white text-[9px] font-bold flex items-center justify-center"
                      style={{ backgroundColor: colors[i] }}
                    >
                      {["I", "II", "III", "IV", "V"][i]}
                    </span>
                    {phase.shortName}
                    <span className="ml-0.5 font-bold">{count}</span>
                  </button>
                )
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filter row */}
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <SlidersHorizontal className="h-3.5 w-3.5 text-gray-400" />
        {FILTER_BUTTONS.map((btn) => (
          <button
            key={btn.key}
            onClick={() => setFilter(btn.key)}
            className={cn(
              "px-3 py-1 rounded-full text-xs font-medium transition-all",
              filter === btn.key
                ? "bg-[#012169] text-white shadow-sm"
                : "bg-white text-gray-600 border border-gray-200 hover:border-[#012169]/40 hover:text-[#012169]"
            )}
          >
            {btn.label}
          </button>
        ))}
        <span className="text-xs text-gray-400 ml-auto">
          {filtered.length} result{filtered.length !== 1 ? "s" : ""}
        </span>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((txn) => (
          <TransactionCard key={txn.id} transaction={txn} />
        ))}
        {filtered.length === 0 && (
          <div className="col-span-3 py-16 flex flex-col items-center text-gray-400">
            <FileText className="h-8 w-8 mb-2 opacity-30" />
            <p className="text-sm">No transactions match this filter</p>
          </div>
        )}
      </div>
    </div>
  )
}
