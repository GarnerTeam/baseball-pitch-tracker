"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { useTransactions } from "@/lib/transaction-store"
import { ROLE_LABELS, getPhaseColor } from "@/lib/data"
import { ContactRole } from "@/types"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Search, Mail, Phone, ExternalLink } from "lucide-react"
import { cn } from "@/lib/utils"

const ROLE_COLORS: Record<string, string> = {
  buyer: "bg-blue-100 text-blue-800",
  seller: "bg-purple-100 text-purple-800",
  coop_agent: "bg-orange-100 text-orange-800",
  lender: "bg-green-100 text-green-800",
  title: "bg-teal-100 text-teal-800",
  tc: "bg-[#012169]/10 text-[#012169]",
  agent: "bg-[#012169]/10 text-[#012169]",
}

const ROLE_ORDER: ContactRole[] = ["buyer", "seller", "coop_agent", "lender", "title", "tc", "agent"]

export default function ContactsPage() {
  const { transactions } = useTransactions()
  const [search, setSearch] = useState("")
  const [roleFilter, setRoleFilter] = useState<ContactRole | "all">("all")

  // Aggregate all contacts with their transaction context
  const allContacts = useMemo(() => {
    const map = new Map<string, { contact: typeof transactions[0]["contacts"][0]; txns: typeof transactions }>()
    for (const txn of transactions) {
      for (const contact of txn.contacts) {
        const key = contact.email || `${contact.name}-${contact.role}`
        if (!map.has(key)) {
          map.set(key, { contact, txns: [txn] })
        } else {
          map.get(key)!.txns.push(txn)
        }
      }
    }
    return Array.from(map.values())
  }, [transactions])

  const filtered = useMemo(() => {
    const q = search.toLowerCase()
    return allContacts.filter(({ contact }) => {
      const matchesSearch =
        contact.name.toLowerCase().includes(q) ||
        contact.email.toLowerCase().includes(q) ||
        contact.phone.includes(q)
      const matchesRole = roleFilter === "all" || contact.role === roleFilter
      return matchesSearch && matchesRole
    })
  }, [allContacts, search, roleFilter])

  const roleCounts = useMemo(() => {
    const counts: Partial<Record<ContactRole | "all", number>> = { all: allContacts.length }
    for (const { contact } of allContacts) {
      counts[contact.role] = (counts[contact.role] ?? 0) + 1
    }
    return counts
  }, [allContacts])

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-[#2D2926]">Contacts</h1>
        <p className="text-gray-500 text-sm mt-0.5">{allContacts.length} contacts across {transactions.length} transactions</p>
      </div>

      {/* Search + filter */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Search by name, email, or phone…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 bg-white border-gray-200"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setRoleFilter("all")}
            className={cn(
              "px-3 py-1.5 rounded-full text-xs font-medium transition-all border",
              roleFilter === "all"
                ? "bg-[#012169] text-white border-[#012169]"
                : "bg-white text-gray-600 border-gray-200 hover:border-[#012169]/40"
            )}
          >
            All ({roleCounts.all})
          </button>
          {ROLE_ORDER.filter((r) => (roleCounts[r] ?? 0) > 0).map((role) => (
            <button
              key={role}
              onClick={() => setRoleFilter(role)}
              className={cn(
                "px-3 py-1.5 rounded-full text-xs font-medium transition-all border",
                roleFilter === role
                  ? "bg-[#012169] text-white border-[#012169]"
                  : "bg-white text-gray-600 border-gray-200 hover:border-[#012169]/40"
              )}
            >
              {ROLE_LABELS[role]} ({roleCounts[role] ?? 0})
            </button>
          ))}
        </div>
      </div>

      {/* Contacts grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map(({ contact, txns }) => (
          <Card key={`${contact.name}-${contact.role}`} className="border-0 shadow-sm hover:shadow-md transition-all bg-white">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="w-11 h-11 rounded-full bg-[#012169]/8 flex items-center justify-center flex-shrink-0 text-sm font-bold text-[#012169]">
                  {contact.name.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <p className="font-semibold text-[#2D2926] text-sm leading-snug">{contact.name}</p>
                    <span className={cn("text-[10px] font-semibold px-2 py-0.5 rounded-full flex-shrink-0", ROLE_COLORS[contact.role] ?? "bg-gray-100 text-gray-600")}>
                      {ROLE_LABELS[contact.role]}
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    {contact.email && (
                      <a href={`mailto:${contact.email}`} className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-[#012169] transition-colors">
                        <Mail className="h-3 w-3 flex-shrink-0" />
                        <span className="truncate">{contact.email}</span>
                      </a>
                    )}
                    {contact.phone && (
                      <a href={`tel:${contact.phone}`} className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-[#012169] transition-colors">
                        <Phone className="h-3 w-3 flex-shrink-0" />
                        {contact.phone}
                      </a>
                    )}
                  </div>
                  {/* Linked transactions */}
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {txns.map((txn) => (
                      <Link
                        key={txn.id}
                        href={`/transactions/${txn.id}`}
                        className="inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded border border-gray-100 hover:border-[#012169]/30 bg-gray-50 hover:bg-[#012169]/5 text-gray-600 hover:text-[#012169] transition-all"
                      >
                        <span
                          className="w-3 h-3 rounded-sm flex-shrink-0"
                          style={{ backgroundColor: getPhaseColor(txn.phase) }}
                        />
                        {txn.address.split(",")[0]}
                        <ExternalLink className="h-2.5 w-2.5 opacity-50" />
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        {filtered.length === 0 && (
          <div className="col-span-3 py-16 text-center text-gray-400">
            <Search className="h-7 w-7 mx-auto mb-2 opacity-30" />
            <p className="text-sm">No contacts found</p>
          </div>
        )}
      </div>
    </div>
  )
}
