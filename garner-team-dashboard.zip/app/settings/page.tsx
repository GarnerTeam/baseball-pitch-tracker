"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { CheckCircle, Settings, Users, Bell, Link } from "lucide-react"

export default function SettingsPage() {
  const [saved, setSaved] = useState(false)
  const [team, setTeam] = useState({
    teamName: "Garner Team",
    brokerage: "Coldwell Banker Realty",
    phone: "443.400.7675",
    website: "GarnerTeam.com",
    tcName: "Sarah Johnson",
    tcEmail: "sjohnson@garnerteam.com",
    tcPhone: "410-555-0105",
  })
  const [notifications, setNotifications] = useState({
    tasksDue: true,
    closingReminder: true,
    newTransaction: true,
    weeklyDigest: false,
  })

  const handleSave = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-[#2D2926]">Settings</h1>
        <p className="text-gray-500 text-sm mt-0.5">Manage your team and dashboard preferences</p>
      </div>

      <div className="space-y-4">
        {/* Team Info */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3 pt-4 px-5">
            <CardTitle className="text-sm font-semibold text-gray-600 flex items-center gap-2">
              <Settings className="h-4 w-4" /> Team Information
            </CardTitle>
          </CardHeader>
          <CardContent className="px-5 pb-5 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs text-gray-600 mb-1 block">Team Name</Label>
                <Input value={team.teamName} onChange={(e) => setTeam((p) => ({ ...p, teamName: e.target.value }))} />
              </div>
              <div>
                <Label className="text-xs text-gray-600 mb-1 block">Brokerage</Label>
                <Input value={team.brokerage} onChange={(e) => setTeam((p) => ({ ...p, brokerage: e.target.value }))} />
              </div>
              <div>
                <Label className="text-xs text-gray-600 mb-1 block">Team Phone</Label>
                <Input value={team.phone} onChange={(e) => setTeam((p) => ({ ...p, phone: e.target.value }))} />
              </div>
              <div>
                <Label className="text-xs text-gray-600 mb-1 block">Website</Label>
                <Input value={team.website} onChange={(e) => setTeam((p) => ({ ...p, website: e.target.value }))} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* TC Info */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3 pt-4 px-5">
            <CardTitle className="text-sm font-semibold text-gray-600 flex items-center gap-2">
              <Users className="h-4 w-4" /> Transaction Coordinator
            </CardTitle>
          </CardHeader>
          <CardContent className="px-5 pb-5 space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="text-xs text-gray-600 mb-1 block">Name</Label>
                <Input value={team.tcName} onChange={(e) => setTeam((p) => ({ ...p, tcName: e.target.value }))} />
              </div>
              <div>
                <Label className="text-xs text-gray-600 mb-1 block">Email</Label>
                <Input type="email" value={team.tcEmail} onChange={(e) => setTeam((p) => ({ ...p, tcEmail: e.target.value }))} />
              </div>
              <div>
                <Label className="text-xs text-gray-600 mb-1 block">Phone</Label>
                <Input value={team.tcPhone} onChange={(e) => setTeam((p) => ({ ...p, tcPhone: e.target.value }))} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3 pt-4 px-5">
            <CardTitle className="text-sm font-semibold text-gray-600 flex items-center gap-2">
              <Bell className="h-4 w-4" /> Notifications
            </CardTitle>
          </CardHeader>
          <CardContent className="px-5 pb-5">
            <div className="space-y-4">
              {[
                { key: "tasksDue", label: "Tasks due soon", desc: "Alert when tasks are due within 3 days" },
                { key: "closingReminder", label: "Closing reminders", desc: "Alert 7 days and 1 day before closing" },
                { key: "newTransaction", label: "New transactions", desc: "Notify team when a transaction is added" },
                { key: "weeklyDigest", label: "Weekly digest", desc: "Summary email every Monday morning" },
              ].map((item, i) => (
                <div key={item.key}>
                  {i > 0 && <Separator className="mb-4" />}
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-[#2D2926]">{item.label}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{item.desc}</p>
                    </div>
                    <Switch
                      checked={notifications[item.key as keyof typeof notifications]}
                      onCheckedChange={(v) => setNotifications((p) => ({ ...p, [item.key]: v }))}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Integrations */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3 pt-4 px-5">
            <CardTitle className="text-sm font-semibold text-gray-600 flex items-center gap-2">
              <Link className="h-4 w-4" /> Integrations
            </CardTitle>
          </CardHeader>
          <CardContent className="px-5 pb-5 space-y-3">
            {[
              { name: "DotLoop", desc: "Connect your DotLoop Premium account to sync documents", status: "Not connected", available: false },
              { name: "Lone Wolf", desc: "Sync transaction data from Lone Wolf back office", status: "Not connected", available: false },
              { name: "Google Calendar", desc: "Sync key dates and deadlines to your calendar", status: "Not connected", available: false },
            ].map((integration) => (
              <div key={integration.name} className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                <div>
                  <p className="text-sm font-semibold text-[#2D2926]">{integration.name}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{integration.desc}</p>
                </div>
                <button
                  disabled={!integration.available}
                  className="text-xs font-medium px-3 py-1.5 rounded-lg border border-gray-200 text-gray-400 bg-white cursor-not-allowed opacity-60"
                >
                  Connect
                </button>
              </div>
            ))}
            <p className="text-xs text-gray-400 pt-1">
              Integrations will be available when the dashboard is deployed. DotLoop Premium API access requires upgrading to DotLoop Premier.
            </p>
          </CardContent>
        </Card>

        {/* Save */}
        <div className="flex justify-end">
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-6 py-2.5 bg-[#012169] hover:bg-[#012169]/90 text-white text-sm font-semibold rounded-lg transition-all shadow-sm"
          >
            {saved ? (
              <>
                <CheckCircle className="h-4 w-4" />
                Saved!
              </>
            ) : (
              "Save Changes"
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
