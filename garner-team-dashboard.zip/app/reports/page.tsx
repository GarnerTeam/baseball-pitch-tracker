"use client"

import { useMemo } from "react"
import { useTransactions } from "@/lib/transaction-store"
import { PHASES, formatCurrency, getPhaseColor } from "@/lib/data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from "recharts"
import { TrendingUp, FileText, CheckCircle, DollarSign } from "lucide-react"

export default function ReportsPage() {
  const { transactions } = useTransactions()

  const stats = useMemo(() => {
    const active = transactions.filter((t) => t.status === "active" || t.status === "pending_close")
    const closed = transactions.filter((t) => t.status === "closed")
    const totalVolume = transactions.reduce((s, t) => s + (t.salePrice ?? t.listPrice), 0)
    const closedVolume = closed.reduce((s, t) => s + (t.salePrice ?? t.listPrice), 0)
    const allTasks = transactions.flatMap((t) => t.tasks)
    const completionRate = allTasks.length > 0
      ? Math.round((allTasks.filter((t) => t.completed).length / allTasks.length) * 100)
      : 0
    return { active: active.length, closed: closed.length, totalVolume, closedVolume, completionRate, allTasks: allTasks.length }
  }, [transactions])

  // Transactions by phase
  const byPhase = useMemo(
    () =>
      PHASES.map((p) => ({
        name: `Ph. ${["I", "II", "III", "IV", "V"][p.number - 1]}`,
        fullName: p.shortName,
        count: transactions.filter((t) => t.phase === p.number).length,
        color: getPhaseColor(p.number),
      })),
    [transactions]
  )

  // Buyer vs Seller
  const byType = useMemo(() => [
    { name: "Buyer Side", value: transactions.filter((t) => t.type === "buyer").length, color: "#418FDE" },
    { name: "Seller Side", value: transactions.filter((t) => t.type === "seller").length, color: "#012169" },
  ], [transactions])

  // Volume by phase
  const volumeByPhase = useMemo(
    () =>
      PHASES.map((p) => ({
        name: `Ph. ${["I", "II", "III", "IV", "V"][p.number - 1]}`,
        volume: transactions
          .filter((t) => t.phase === p.number)
          .reduce((s, t) => s + (t.salePrice ?? t.listPrice), 0),
        color: getPhaseColor(p.number),
      })),
    [transactions]
  )

  const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: { value: number; name?: string }[]; label?: string }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white border border-gray-100 shadow-lg rounded-lg px-3 py-2 text-xs">
          <p className="font-semibold text-gray-700">{label}</p>
          <p className="text-[#012169]">{payload[0].value}</p>
        </div>
      )
    }
    return null
  }

  const VolumeTooltip = ({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white border border-gray-100 shadow-lg rounded-lg px-3 py-2 text-xs">
          <p className="font-semibold text-gray-700">{label}</p>
          <p className="text-[#012169]">{formatCurrency(payload[0].value)}</p>
        </div>
      )
    }
    return null
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-[#2D2926]">Reports</h1>
        <p className="text-gray-500 text-sm mt-0.5">Pipeline overview for Garner Team</p>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { label: "Total Transactions", value: transactions.length, sub: "all time", icon: FileText, color: "#012169" },
          { label: "Active Pipeline", value: formatCurrency(stats.totalVolume), sub: `${stats.active} transactions`, icon: TrendingUp, color: "#418FDE" },
          { label: "Closed Volume", value: formatCurrency(stats.closedVolume), sub: `${stats.closed} closed`, icon: DollarSign, color: "#C9A84C" },
          { label: "Task Completion", value: `${stats.completionRate}%`, sub: `${stats.allTasks} total tasks`, icon: CheckCircle, color: "#5C86A0" },
        ].map((s) => (
          <Card key={s.label} className="border-0 shadow-sm overflow-hidden">
            <div className="h-1" style={{ backgroundColor: s.color }} />
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500 font-medium uppercase tracking-wide mb-1">{s.label}</p>
                  <p className="text-2xl font-bold text-[#2D2926]">{s.value}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{s.sub}</p>
                </div>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${s.color}15` }}>
                  <s.icon className="h-5 w-5" style={{ color: s.color }} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        {/* Transactions by Phase */}
        <Card className="border-0 shadow-sm lg:col-span-2">
          <CardHeader className="pb-2 pt-4 px-5">
            <CardTitle className="text-sm font-semibold text-gray-600">Transactions by Phase</CardTitle>
          </CardHeader>
          <CardContent className="px-5 pb-4">
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={byPhase} barSize={36}>
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#63666A" }} />
                <YAxis allowDecimals={false} axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#63666A" }} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                  {byPhase.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Buyer vs Seller */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2 pt-4 px-5">
            <CardTitle className="text-sm font-semibold text-gray-600">Buyer vs Seller</CardTitle>
          </CardHeader>
          <CardContent className="px-5 pb-4 flex flex-col items-center">
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie
                  data={byType}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={70}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {byType.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(v: number) => [v, ""]} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex gap-4 mt-2">
              {byType.map((t) => (
                <div key={t.name} className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: t.color }} />
                  <span className="text-xs text-gray-600">{t.name} <strong>{t.value}</strong></span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Volume by Phase */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2 pt-4 px-5">
          <CardTitle className="text-sm font-semibold text-gray-600">Pipeline Volume by Phase</CardTitle>
        </CardHeader>
        <CardContent className="px-5 pb-4">
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={volumeByPhase} barSize={40}>
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#63666A" }} />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 10, fill: "#63666A" }}
                tickFormatter={(v: number) => v >= 1000000 ? `$${(v / 1000000).toFixed(1)}M` : v >= 1000 ? `$${(v / 1000).toFixed(0)}K` : `$${v}`}
              />
              <Tooltip content={<VolumeTooltip />} />
              <Bar dataKey="volume" radius={[4, 4, 0, 0]}>
                {volumeByPhase.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )
}
