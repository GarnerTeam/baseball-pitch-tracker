"use client"

import { TransactionProvider } from "@/lib/transaction-store"

export function Providers({ children }: { children: React.ReactNode }) {
  return <TransactionProvider>{children}</TransactionProvider>
}
