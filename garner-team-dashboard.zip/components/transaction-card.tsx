"use client"

import Link from "next/link"
import { Transaction } from "@/types"
import { PHASES, formatCurrency, getDaysUntil, getPhaseColor, STATUS_LABELS } from "@/lib/data"
import { Card, CardContent } from "@/components/ui/card"
import { Calendar, ChevronRight, Clock, Hash } from "lucide-react"
import { cn } from "@/lib/utils"

interface TransactionCardProps {
  transaction: Transaction
}

const STATUS_STYLES: Record<string, string> = {
  active: "bg-emerald-100 text-emerald-800",
  pending_close: "bg-amber-100 text-amber-800",
  closed: "bg-gray-100 text-gray-600",
  withdrawn: "bg-red-100 text-red-800",
}

export function TransactionCard({ transaction }: TransactionCardProps) {
  const phase = PHASES[transaction.phase - 1]
  const phaseColor = getPhaseColor(transaction.phase)
  const completedTasks = transaction.tasks.filter((t) => t.completed).length
  const totalTasks = transaction.tasks.length
  const progressPercent = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0

  const pendingWithDue = transaction.tasks
    .filter((t) => !t.completed && t.dueDate)
    .sort((a, b) => new Date(a.dueDate!).getTime() - new Date(b.dueDate!).getTime())
  const nextDeadline = pendingWithDue[0]

  const daysToClose = transaction.closingDate ? getDaysUntil(transaction.closingDate) : null

  return (
    <Link href={`/transactions/${transaction.id}`}>
      <Card className="hover:shadow-lg transition-all duration-200 hover:-translate-y-0.5 cursor-pointer group border border-gray-100 bg-white overflow-hidden">
        {/* Phase color bar */}
        <div className="h-1 w-full" style={{ backgroundColor: phaseColor }} />

        <CardContent className="p-5">
          {/* Status badges */}
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <span className={cn("text-[10px] font-semibold px-2 py-0.5 rounded-full", STATUS_STYLES[transaction.status])}>
                {STATUS_LABELS[transaction.status]}
              </span>
              <span
                className={cn(
                  "text-[10px] font-semibold px-2 py-0.5 rounded-full",
                  transaction.type === "buyer"
                    ? "bg-blue-50 text-blue-700"
                    : "bg-purple-50 text-purple-700"
                )}
              >
                {transaction.type === "buyer" ? "Buyer" : "Seller"}
              </span>
            </div>
            <ChevronRight className="h-4 w-4 text-gray-300 group-hover:text-[#012169] transition-colors" />
          </div>

          {/* Address */}
          <h3 className="font-semibold text-[#2D2926] text-sm leading-snug mb-1 group-hover:text-[#012169] transition-colors">
            {transaction.address}
          </h3>

          {/* MLS + Price */}
          <div className="flex items-center gap-3 mb-3 text-xs text-gray-500">
            <span className="flex items-center gap-1">
              <Hash className="h-3 w-3" />
              {transaction.mlsNumber}
            </span>
            <span className="font-bold text-[#2D2926]">
              {transaction.salePrice
                ? formatCurrency(transaction.salePrice)
                : formatCurrency(transaction.listPrice)}
            </span>
            {transaction.salePrice && transaction.salePrice !== transaction.listPrice && (
              <span className="line-through text-gray-400">{formatCurrency(transaction.listPrice)}</span>
            )}
          </div>

          {/* Phase + progress */}
          <div className="mb-3">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: phaseColor }}>
                Phase {["I", "II", "III", "IV", "V"][transaction.phase - 1]}: {phase.shortName}
              </span>
              <span className="text-[10px] text-gray-400">
                {completedTasks}/{totalTasks} tasks
              </span>
            </div>
            {/* Custom progress bar */}
            <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all"
                style={{ width: `${progressPercent}%`, backgroundColor: phaseColor }}
              />
            </div>
          </div>

          {/* Footer row */}
          <div className="flex items-center justify-between text-[10px]">
            {transaction.closingDate && daysToClose !== null ? (
              <span
                className={cn(
                  "flex items-center gap-1 font-medium",
                  daysToClose <= 0
                    ? "text-red-500"
                    : daysToClose <= 7
                    ? "text-red-500"
                    : daysToClose <= 14
                    ? "text-amber-500"
                    : "text-gray-500"
                )}
              >
                <Calendar className="h-3 w-3" />
                {daysToClose < 0
                  ? "Past closing"
                  : daysToClose === 0
                  ? "Closes TODAY"
                  : `Closes in ${daysToClose}d`}
              </span>
            ) : (
              <span className="text-gray-300">No closing date</span>
            )}

            {nextDeadline && (
              <span
                className={cn(
                  "flex items-center gap-1",
                  getDaysUntil(nextDeadline.dueDate!) <= 0
                    ? "text-red-500 font-medium"
                    : getDaysUntil(nextDeadline.dueDate!) <= 3
                    ? "text-amber-500"
                    : "text-gray-400"
                )}
              >
                <Clock className="h-3 w-3" />
                {getDaysUntil(nextDeadline.dueDate!) <= 0
                  ? "Task overdue"
                  : `Task in ${getDaysUntil(nextDeadline.dueDate!)}d`}
              </span>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
