"use client"

import { PHASES, getPhaseColor } from "@/lib/data"
import { PhaseNumber } from "@/types"
import { cn } from "@/lib/utils"
import { Check } from "lucide-react"

interface PhaseStepperProps {
  currentPhase: PhaseNumber
  className?: string
}

export function PhaseStepper({ currentPhase, className }: PhaseStepperProps) {
  return (
    <div className={cn("w-full", className)}>
      <div className="flex items-start">
        {PHASES.map((phase, index) => {
          const isCompleted = phase.number < currentPhase
          const isCurrent = phase.number === currentPhase
          const isFuture = phase.number > currentPhase
          const isLast = index === PHASES.length - 1
          const color = getPhaseColor(phase.number)

          return (
            <div key={phase.number} className="flex items-start flex-1 min-w-0">
              {/* Step + label */}
              <div className="flex flex-col items-center flex-shrink-0">
                {/* Circle */}
                <div
                  className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all",
                    isCompleted && "text-white",
                    isCurrent && "text-white ring-4 ring-offset-2 shadow-md",
                    isFuture && "text-white/60 bg-gray-200"
                  )}
                  style={{
                    backgroundColor: isCompleted || isCurrent ? color : undefined,
                    ringColor: isCurrent ? color : undefined,
                    boxShadow: isCurrent ? `0 0 0 3px white, 0 0 0 5px ${color}` : undefined,
                  }}
                >
                  {isCompleted ? (
                    <Check className="h-3.5 w-3.5" />
                  ) : (
                    <span>{phase.number}</span>
                  )}
                </div>
                {/* Label */}
                <div className="mt-2 text-center px-1">
                  <p
                    className={cn(
                      "text-[10px] font-semibold leading-tight",
                      isCurrent ? "text-[#2D2926]" : isCompleted ? "text-gray-500" : "text-gray-400"
                    )}
                    style={{ color: isCurrent ? color : undefined }}
                  >
                    Phase {["I", "II", "III", "IV", "V"][index]}
                  </p>
                  <p
                    className={cn(
                      "text-[9px] leading-tight mt-0.5",
                      isCurrent ? "text-gray-700 font-medium" : "text-gray-400"
                    )}
                  >
                    {phase.shortName}
                  </p>
                </div>
              </div>

              {/* Connector */}
              {!isLast && (
                <div className="flex-1 mt-4 mx-1">
                  <div className="h-0.5 w-full rounded-full bg-gray-200 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: isCompleted ? "100%" : isCurrent ? "50%" : "0%",
                        backgroundColor: color,
                      }}
                    />
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
