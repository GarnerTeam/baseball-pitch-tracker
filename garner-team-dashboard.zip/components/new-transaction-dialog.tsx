"use client"

import { useState } from "react"
import { useTransactions } from "@/lib/transaction-store"
import { Transaction, Task, TransactionContact } from "@/types"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Plus } from "lucide-react"

const BUYER_TASKS: Omit<Task, "id">[] = [
  { phase: 1, title: "Buyer consultation", completed: false },
  { phase: 1, title: "Pre-approval letter received", completed: false, priority: "high" },
  { phase: 1, title: "Sign buyer agency agreement", completed: false, priority: "high" },
]

const SELLER_TASKS: Omit<Task, "id">[] = [
  { phase: 1, title: "Seller consultation", completed: false },
  { phase: 1, title: "CMA / pricing analysis", completed: false },
  { phase: 1, title: "Execute listing agreement", completed: false, priority: "high" },
  { phase: 1, title: "Home prep / staging consultation", completed: false, priority: "medium" },
  { phase: 1, title: "Order professional photography", completed: false, priority: "medium" },
  { phase: 1, title: "Go Active on MLS", completed: false, priority: "medium" },
]

const EMPTY = {
  address: "",
  mlsNumber: "",
  type: "buyer" as "buyer" | "seller",
  listPrice: "",
  closingDate: "",
  clientName: "",
  clientEmail: "",
  clientPhone: "",
}

export function NewTransactionDialog() {
  const { addTransaction } = useTransactions()
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({ ...EMPTY })
  const [errors, setErrors] = useState<Partial<typeof EMPTY>>({})

  const set = (key: keyof typeof EMPTY, value: string) => {
    setForm((p) => ({ ...p, [key]: value }))
    setErrors((p) => ({ ...p, [key]: "" }))
  }

  const validate = () => {
    const e: Partial<typeof EMPTY> = {}
    if (!form.address.trim()) e.address = "Required"
    if (!form.mlsNumber.trim()) e.mlsNumber = "Required"
    if (!form.listPrice || isNaN(Number(form.listPrice.replace(/[$,]/g, ""))))
      e.listPrice = "Enter a valid amount"
    if (!form.clientName.trim()) e.clientName = "Required"
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handleSubmit = () => {
    if (!validate()) return

    const id = `txn-${Date.now()}`
    const tasks: Task[] = (form.type === "buyer" ? BUYER_TASKS : SELLER_TASKS).map((t, i) => ({
      ...t,
      id: `${id}-t${i}`,
    }))
    const contact: TransactionContact = {
      id: `${id}-c0`,
      name: form.clientName,
      email: form.clientEmail,
      phone: form.clientPhone,
      role: form.type === "buyer" ? "buyer" : "seller",
    }
    const txn: Transaction = {
      id,
      address: form.address.trim(),
      mlsNumber: form.mlsNumber.trim(),
      phase: 1,
      status: "active",
      type: form.type,
      listPrice: Number(form.listPrice.replace(/[$,]/g, "")),
      closingDate: form.closingDate || undefined,
      createdAt: new Date().toISOString(),
      contacts: [contact],
      tasks,
    }

    addTransaction(txn)
    setOpen(false)
    setForm({ ...EMPTY })
    setErrors({})
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button className="flex items-center gap-2 bg-[#012169] hover:bg-[#012169]/90 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors shadow-sm">
          <Plus className="h-4 w-4" />
          New Transaction
        </button>
      </DialogTrigger>

      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-[#012169] text-lg">New Transaction</DialogTitle>
          <p className="text-xs text-gray-500">Starts in Phase I — Interview to Active</p>
        </DialogHeader>

        <div className="space-y-5 pt-1">
          {/* Property Info */}
          <div>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">Property</p>
            <div className="space-y-3">
              <div>
                <Label className="text-xs text-gray-600 mb-1 block">Property Address *</Label>
                <Input
                  placeholder="123 Main St, Columbia, MD 21044"
                  value={form.address}
                  onChange={(e) => set("address", e.target.value)}
                  className={errors.address ? "border-red-400 focus-visible:ring-red-400" : ""}
                />
                {errors.address && <p className="text-xs text-red-500 mt-0.5">{errors.address}</p>}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-gray-600 mb-1 block">MLS Number *</Label>
                  <Input
                    placeholder="MDHO2000000"
                    value={form.mlsNumber}
                    onChange={(e) => set("mlsNumber", e.target.value)}
                    className={errors.mlsNumber ? "border-red-400" : ""}
                  />
                  {errors.mlsNumber && <p className="text-xs text-red-500 mt-0.5">{errors.mlsNumber}</p>}
                </div>
                <div>
                  <Label className="text-xs text-gray-600 mb-1 block">Transaction Type *</Label>
                  <Select value={form.type} onValueChange={(v) => set("type", v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="buyer">Buyer Side</SelectItem>
                      <SelectItem value="seller">Seller Side</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-gray-600 mb-1 block">List Price *</Label>
                  <Input
                    placeholder="485000"
                    value={form.listPrice}
                    onChange={(e) => set("listPrice", e.target.value)}
                    className={errors.listPrice ? "border-red-400" : ""}
                  />
                  {errors.listPrice && <p className="text-xs text-red-500 mt-0.5">{errors.listPrice}</p>}
                </div>
                <div>
                  <Label className="text-xs text-gray-600 mb-1 block">Closing Date</Label>
                  <Input
                    type="date"
                    value={form.closingDate}
                    onChange={(e) => set("closingDate", e.target.value)}
                  />
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Client Info */}
          <div>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">
              Primary Client
            </p>
            <div className="space-y-3">
              <div>
                <Label className="text-xs text-gray-600 mb-1 block">Client Name *</Label>
                <Input
                  placeholder="John & Jane Smith"
                  value={form.clientName}
                  onChange={(e) => set("clientName", e.target.value)}
                  className={errors.clientName ? "border-red-400" : ""}
                />
                {errors.clientName && <p className="text-xs text-red-500 mt-0.5">{errors.clientName}</p>}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-gray-600 mb-1 block">Email</Label>
                  <Input
                    type="email"
                    placeholder="client@email.com"
                    value={form.clientEmail}
                    onChange={(e) => set("clientEmail", e.target.value)}
                  />
                </div>
                <div>
                  <Label className="text-xs text-gray-600 mb-1 block">Phone</Label>
                  <Input
                    placeholder="410-555-0100"
                    value={form.clientPhone}
                    onChange={(e) => set("clientPhone", e.target.value)}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-1">
            <button
              onClick={() => { setOpen(false); setErrors({}) }}
              className="flex-1 py-2.5 text-sm text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              className="flex-1 py-2.5 text-sm font-semibold text-white bg-[#012169] rounded-lg hover:bg-[#012169]/90 transition-colors"
            >
              Create Transaction
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
