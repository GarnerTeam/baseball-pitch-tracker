"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, FileText, Users, BarChart3, Settings, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"
import { useTransactions } from "@/lib/transaction-store"

export function Sidebar() {
  const pathname = usePathname()
  const { transactions } = useTransactions()
  const activeCount = transactions.filter(
    (t) => t.status === "active" || t.status === "pending_close"
  ).length

  const navItems = [
    { href: "/", label: "Dashboard", icon: Home },
    { href: "/transactions", label: "Transactions", icon: FileText, badge: activeCount },
    { href: "/contacts", label: "Contacts", icon: Users },
    { href: "/reports", label: "Reports", icon: BarChart3 },
    { href: "/settings", label: "Settings", icon: Settings },
  ]

  return (
    <aside className="w-60 min-h-screen bg-[#012169] flex flex-col flex-shrink-0 shadow-xl">
      {/* Logo */}
      <div className="px-5 py-5 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#C9A84C] to-[#a8863c] flex items-center justify-center shadow-sm flex-shrink-0">
            <span className="text-white font-bold text-base italic">G</span>
          </div>
          <div className="min-w-0">
            <h1 className="text-white font-bold text-sm leading-tight truncate">Garner Team</h1>
            <p className="text-white/50 text-xs truncate">Coldwell Banker Realty</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5">
        {navItems.map((item) => {
          const isActive =
            pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href))
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-all",
                isActive
                  ? "bg-white/15 text-white font-medium"
                  : "text-white/65 hover:bg-white/10 hover:text-white"
              )}
            >
              <item.icon className="h-4 w-4 flex-shrink-0" />
              <span className="flex-1">{item.label}</span>
              {"badge" in item && item.badge !== undefined && item.badge > 0 && (
                <span className="bg-[#418FDE] text-white text-xs font-semibold px-1.5 py-0.5 rounded-full leading-none">
                  {item.badge}
                </span>
              )}
              {isActive && <ChevronRight className="h-3 w-3 opacity-50" />}
            </Link>
          )
        })}
      </nav>

      {/* Phase Legend */}
      <div className="px-5 py-4 border-t border-white/10">
        <p className="text-white/40 text-xs font-medium uppercase tracking-wider mb-2">Phases</p>
        <div className="space-y-1">
          {[
            { num: "I", label: "Interview to Active", color: "#418FDE" },
            { num: "II", label: "Offer / Compromise", color: "#7BA5D4" },
            { num: "III", label: "Contingency Release", color: "#5C86A0" },
            { num: "IV", label: "Settlement", color: "#C9A84C" },
            { num: "V", label: "Post Closing", color: "#7A7E81" },
          ].map((p) => (
            <div key={p.num} className="flex items-center gap-2">
              <div
                className="w-4 h-4 rounded-sm flex-shrink-0 flex items-center justify-center"
                style={{ backgroundColor: p.color }}
              >
                <span className="text-white text-[8px] font-bold">{p.num}</span>
              </div>
              <span className="text-white/45 text-xs truncate">{p.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* User */}
      <div className="px-5 py-4 border-t border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-[#418FDE] flex items-center justify-center flex-shrink-0">
            <span className="text-white text-xs font-bold">TC</span>
          </div>
          <div className="min-w-0">
            <p className="text-white text-xs font-medium truncate">Sarah Johnson</p>
            <p className="text-white/45 text-xs">Transaction Coordinator</p>
          </div>
        </div>
      </div>
    </aside>
  )
}
