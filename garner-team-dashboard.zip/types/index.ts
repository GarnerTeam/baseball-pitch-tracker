export type PhaseNumber = 1 | 2 | 3 | 4 | 5

export interface Phase {
  number: PhaseNumber
  name: string
  shortName: string
  description: string
}

export type ContactRole = 'buyer' | 'seller' | 'coop_agent' | 'lender' | 'title' | 'tc' | 'agent'
export type TransactionType = 'buyer' | 'seller'
export type TransactionStatus = 'active' | 'pending_close' | 'closed' | 'withdrawn'
export type UserRole = 'tc' | 'client' | 'coop_agent'

export interface TransactionContact {
  id: string
  name: string
  email: string
  phone: string
  role: ContactRole
}

export interface Task {
  id: string
  phase: PhaseNumber
  title: string
  completed: boolean
  dueDate?: string
  assignedTo?: string
  priority?: 'high' | 'medium' | 'low'
}

export interface Transaction {
  id: string
  address: string
  mlsNumber: string
  phase: PhaseNumber
  status: TransactionStatus
  type: TransactionType
  listPrice: number
  salePrice?: number
  contractDate?: string
  closingDate?: string
  inspectionDeadline?: string
  financingDeadline?: string
  createdAt: string
  contacts: TransactionContact[]
  tasks: Task[]
  notes?: string
}
